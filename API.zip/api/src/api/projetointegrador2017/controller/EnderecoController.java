package api.projetointegrador2017.controller;

import javax.ws.rs.core.Response;

import api.projetointegrador2017.dao.EnderecoDAO;

/**
 * 
 * @author Matheus Gambarin Classe respons�vel por ser o controlador entre o
 *         resource e a camada DAO de endere�o
 */
public class EnderecoController {

	public Response getEnderecoUsuario(int usuarioID) {
		return EnderecoDAO.getInstance().buscarEnderecoUsuario(usuarioID);
	}
}
