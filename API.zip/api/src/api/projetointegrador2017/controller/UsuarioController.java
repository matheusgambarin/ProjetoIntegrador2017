package api.projetointegrador2017.controller;

import java.util.ArrayList;

import javax.ws.rs.core.Response;

import api.projetointegrador2017.dao.UsuarioDAO;
import api.projetointegrador2017.model.Usuario;

/**
 * Classe respons�vel por ser o controlador de usu�rios entre o resource e DAO
 * 
 * @author Matheus Gambarin
 *
 */
public class UsuarioController {

	public ArrayList<Usuario> listarTodos() {
		return UsuarioDAO.getInstance().listarTodos();
	}

	public Response Inserir(Usuario usuario) {
		return UsuarioDAO.getInstance().Inserir(usuario);
	}

	public Response alterarUsuario(int id, Usuario usuario) {
		return UsuarioDAO.getInstance().Alterar(usuario, id);
	}

	public Response GetUsuario(int id) {
		return UsuarioDAO.getInstance().GetUsuario(id);
	}

	public Response login(String email, String senha) {
		return UsuarioDAO.getInstance().Login(email, senha);
	}



	// public Response alterarUsuario(int id, Usuario usuario) {
	// return UsuarioDAO.getInstance().Alterar(usuario);
	// }
}
