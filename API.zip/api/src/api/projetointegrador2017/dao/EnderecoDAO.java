package api.projetointegrador2017.dao;


import javax.persistence.EntityManager;
import javax.ws.rs.core.Response;

import api.projetointegrador2017.model.Endereco;
import api.projetointegrador2017.model.Usuario;

/**
 * 
 * @author Matheus Gambarin
 * 
 *         Classe respons�vel por conter os met�dos CRUD de endere�o
 */
public class EnderecoDAO {

	private static EnderecoDAO instance;
	private EntityManager entityManager;

	/**
	 * M�todo responsavel por criar uma instancia
	 * 
	 * @author Matheus Gambarin
	 * @return new instance de enderecoDAO
	 */

	public static EnderecoDAO getInstance() {
		if (instance == null)
			instance = new EnderecoDAO();
		return instance;
	}

	public Response buscarEnderecoUsuario(int usuarioID) {

		entityManager = api.projetointegrador2017.factory.ConnectionFactory.getEntityManager();

		try {
			Usuario usuario =  (Usuario) entityManager.createQuery("FROM " + Usuario.class.getTypeName() + " where usuarioid = " + usuarioID).getSingleResult();
			Endereco endereco = (Endereco) entityManager
					.createQuery("FROM " + Endereco.class.getTypeName() + " where id = " + usuario.getEnderecoid())
					.getSingleResult();
			return Response.ok().entity(endereco).build();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
}
