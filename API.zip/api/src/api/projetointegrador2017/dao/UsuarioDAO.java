package api.projetointegrador2017.dao;

import java.util.ArrayList;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.ws.rs.core.Response;

import api.projetointegrador2017.factory.ConnectionFactory;
import api.projetointegrador2017.model.Usuario;

/**
 * Classe respons�vel pelo CRUD de USUARIO
 * 
 * @author Matheus Gambarin
 *
 */
public class UsuarioDAO extends ConnectionFactory {
	private EntityManager entityManager;
	private static UsuarioDAO instance;

	/**
	 * met�do respons�vel por criar uma instancia de usu�rio
	 * 
	 * @author Matheus Gambarin
	 * @return
	 */
	public static UsuarioDAO getInstance() {
		if (instance == null)
			instance = new UsuarioDAO();
		return instance;
	}

	/**
	 * Met�do respons�vel por listar todos os usu�rios
	 * 
	 * @author Matheus Gambarin
	 * @return
	 */
	public ArrayList<Usuario> listarTodos() {
		return null;
	}

	/**
	 * @author Matheus Gambarin
	 * @param usuario
	 * @return
	 * 
	 * 		M�todo respons�vel por inserir um novo usu�rio
	 */

	public Response Inserir(Usuario usuario) {
		entityManager = getEntityManager();

		Usuario usuarioPraInserir = new Usuario();

		usuarioPraInserir.setData_Alteracao(new Date());
		usuarioPraInserir.setData_Cadastro(new Date());
		usuarioPraInserir.setExcluido(false);
		usuarioPraInserir.setNovo(true);
		usuarioPraInserir.setNome(usuario.getNome());
		usuarioPraInserir.setEmail(usuario.getEmail());
		usuarioPraInserir.setSenha(usuario.getSenha());
		usuarioPraInserir.setTelefone(usuario.getTelefone());

		try {
			entityManager.getTransaction().begin();
			entityManager.persist(usuarioPraInserir);
			entityManager.getTransaction().commit();
			return Response.ok().entity("Usu�rio cadastrado com sucesso").build();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return Response.serverError().entity("Erro ao cadastrar usu�rio").build();
		}
	}

	/**
	 * @@author Matheus Gambarin
	 * @param usuario
	 * @param id
	 * 
	 *            Met�do respons�vel por alterar o objeto usu�rio
	 * @return
	 */
	public Response Alterar(Usuario usuario, int id) {
		try {
			entityManager = getEntityManager();
			entityManager.getTransaction().begin();
			String exe = "Update Usuario set nome = :nome, email = :email, "
					+ "senha = :senha, telefone = :telefone, data_alteracao = :data_alteracao, "
					+ "enderecoid = :enderecoid" + "  where id = :id";
			Query query = entityManager.createQuery(exe);
			query.setParameter("id", id);
			query.setParameter("nome", usuario.getNome());
			query.setParameter("email", usuario.getEmail());
			query.setParameter("senha", usuario.getSenha());
			query.setParameter("data_alteracao", new Date());
			query.setParameter("telefone", usuario.getTelefone());
			query.setParameter("enderecoid", usuario.getEnderecoid());
			int linhasAfetadas = query.executeUpdate();
			if (linhasAfetadas == 0) {
				return Response.status(Response.Status.BAD_REQUEST).entity("Este usu�rio n�o existe").build();
			}
			entityManager.getTransaction().commit();
			return Response.ok("Usu�rio alterado com sucesso").build();
		} catch (Exception e) {
			return Response.status(Response.Status.BAD_REQUEST).entity("Erro ao alterar usu�rio: " + e.getMessage())
					.build();
		}
	}

	/**
	 * @author Matheus Gambarin
	 * @param id
	 * @return usu�rio correspondente do id
	 * 
	 *         M�todo respons�vel por pegar o usu�rio no banco pelo ID
	 */
	public Response GetUsuario(int id) {
		try {
			entityManager = getEntityManager();
			return Response.ok().entity(entityManager
					.createQuery("FROM " + Usuario.class.getTypeName() + " Where id=" + id).getSingleResult()).build();

		} catch (Exception e) {
			return Response.status(Response.Status.BAD_REQUEST).entity("Erro ao buscar usu�rio: " + e.getMessage())
					.build();
		}
	}

	/**
	 * @author Matheus Gambarin
	 * @param email
	 * @param senha
	 * 
	 *            M�todo respons�vel por realizar login
	 * @return resposta de login
	 */

	public Response Login(String email, String senha) {
		try {

			entityManager = getEntityManager();
			int result = entityManager
					.createQuery(
							"FROM " + Usuario.class.getTypeName() + "where email = " + email + " AND senha = " + senha)
					.getFirstResult();
			if (result != 1) {
				return Response.status(Response.Status.BAD_REQUEST).entity("Usuario ou senha incorretos").build();
			}
			return Response.ok().entity("Logado com sucessso").build();
		} catch (Exception e) {
			return Response.status(Response.Status.BAD_REQUEST).entity("Erro ao realizar login: " + e.getMessage())
					.build();
		}
	}

}