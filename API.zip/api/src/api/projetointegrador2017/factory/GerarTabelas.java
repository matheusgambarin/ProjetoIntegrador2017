package api.projetointegrador2017.factory;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class GerarTabelas {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("ProjetoIntegrador");

		factory.close();
	}
}
