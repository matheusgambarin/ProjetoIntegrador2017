package api.projetointegrador2017.resource;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;
//
import api.projetointegrador2017.controller.AnimalController;
import api.projetointegrador2017.model.Animal;

/**
 * Classe respons�vel por conter os met�dos rest de acesso ao webservice
 * 
 * @author Matheus Gambarin
 *
 */

@Path("/animal")
public class AnimalResource {

	private static final String UPLOAD_FOLDER = "~/adoteumpet/img/";

	@Context
	private UriInfo context;

	/**
	 * Retorna o caminho da imagem no servidor
	 * 
	 * @author Matheus Gambarin
	 * @return Resposta de erro em caso de formato errado de data e exce��o ou
	 *         sucesso se o arquivo for salvo com sucesso
	 */
	@POST
	@Path("/imagem")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadFile(@FormDataParam("file") InputStream uploadedInputStream,
			@FormDataParam("file") FormDataContentDisposition fileDetail) {

		// check if all form parameters are provided
		if (uploadedInputStream == null || fileDetail == null)
			return Response.status(400).entity("Tipo de dado incorreto").build();
		// create our destination folder, if it not exists
		try {
			createFolderIfNotExists(UPLOAD_FOLDER);
		} catch (SecurityException se) {
			return Response.status(500).entity("N�o foi poss�vel criar o caminho do diret�rio").build();
		}
		String uploadedFileLocation = UPLOAD_FOLDER + fileDetail.getFileName();
		try {
			saveToFile(uploadedInputStream, uploadedFileLocation);
		} catch (IOException e) {
			return Response.status(500).entity("N�o foi poss�vel salvar a imagem").build();
		}
		return Response.status(200).entity("Arquivo salvo com sucesso" + uploadedFileLocation).build();
	}

	/**
	 * Met�do respons�vel por salvar a imagem no local especificado *
	 * 
	 * @author Matheus Gambarin
	 * @param inStream
	 *            - Imagem a ser salva
	 * @param target
	 *            - Caminho completo para salvar a imagem
	 */

	private void saveToFile(InputStream inStream, String target) throws IOException {
		OutputStream out = null;
		int read = 0;
		byte[] bytes = new byte[1024];
		out = new FileOutputStream(new File(target));
		while ((read = inStream.read(bytes)) != -1) {
			out.write(bytes, 0, read);
		}
		out.flush();
		out.close();
	}

	/**
	 * Met�do respons�vel por criar o diret�rio caso n�o exista ainda
	 * 
	 * @author Matheus Gambarin
	 * @param dirName
	 *            - Nome completo do caminho do diret�rio
	 * @throws SecurityException
	 *             - No caso de voc� n�o ter permiss�o para criar um novo
	 *             diret�rio
	 */

	private void createFolderIfNotExists(String dirName) throws SecurityException {
		File theDir = new File(dirName);
		if (!theDir.exists()) {
			theDir.mkdir();
		}
	}

	/**
	 * Retorna todos os animais cadastrados
	 * 
	 * @author Matheus Gambarin
	 * @return
	 */
	@GET
	@Path("/listartodos")
	@Produces("application/json")
	public List<Animal> listarTodos() {
		return new AnimalController().listarTodos();
	}

	/**
	 * Rota respons�vel por receber objeto do tipo animal
	 * 
	 * @author Matheus Gambarin
	 * @param animal
	 *            objeto do tipo Animal
	 * @return
	 */
	@POST
	@Path("/inserir")
	@Consumes("application/json")
	public Response inserirAnimal(Animal animal) {
		new AnimalController().inserirAnimal(animal);
		return Response.ok().entity("Inser��o realizada com sucesso").build();
	}

	/**
	 * Rota respons�vel por receber um animal e alterar ele
	 * 
	 * @author Matheus Gambarin
	 * @param id
	 * @param animal
	 * @return
	 */
	@PUT
	@Path("/alterar/{id}")
	@Consumes("application/json")
	public Response alterarAnimal(@PathParam("id") int id, Animal animal) {
		int count = new AnimalController().alterarAnimal(id, animal);
		if (count == 0) {
			return Response.status(Response.Status.BAD_REQUEST).entity("N�o foi encontrado nenhum animal com este ID")
					.build();
		}
		return Response.ok().entity("Alterado com sucesso").build();
	}

	/**
	 * Rota respons�vel por trazer os animais do tipo venda
	 * 
	 * @author Matheus Gambarin
	 * @return
	 */
	@GET
	@Path("/venda")
	@Produces("application/json")
	public List<Animal> listarAnimaisVenda() {
		return new AnimalController().listarAnimaisVenda();
	}

	/**
	 * Rota respons�vel por trazer os animais do tipo ado��o
	 * 
	 * @author Matheus Gambarin
	 * @return
	 */
	@GET
	@Path("/adocao")
	@Produces("application/json")
	public List<Animal> listarAnimaisAdocao() {
		return new AnimalController().listarAnimaisAdocao();
	}

	/**
	 * Rota respons�vel por trazer os animais do tipo perdido
	 * 
	 * @author Matheus Gambarin
	 * @return
	 */
	@GET
	@Path("/perdido")
	@Produces("application/json")
	public List<Animal> listarAnimaisPerdidos() {
		return new AnimalController().listarAnimaisPerdidos();
	}

	/**
	 * @author Matheus Gambarin
	 * 
	 *         Rota respons�vel por trazer os anuncios de um usu�rio
	 * @param usuarioid
	 * @return
	 */
	@GET
	@Path("/meusanuncios/{usuarioid}")
	@Produces("application/json")
	public List<Animal> listarAnimaisDoUsuario(@PathParam("usuarioid") int usuarioid) {
		return new AnimalController().listarAnimaisUsuario(usuarioid);
	}
}
