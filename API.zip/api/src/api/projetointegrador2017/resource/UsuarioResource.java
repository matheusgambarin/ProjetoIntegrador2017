package api.projetointegrador2017.resource;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import api.projetointegrador2017.controller.UsuarioController;
import api.projetointegrador2017.model.Usuario;

/**
 * Classe respons�vel por conter os met�dos rest de acesso ao webservice
 * 
 * @author Matheus Gambarin
 *
 */

@Path("/usuario")
public class UsuarioResource {

	@GET
	@Path("/listartodos")
	@Produces("application/json")
	public ArrayList<Usuario> listarTodos() {
		return new UsuarioController().listarTodos();
	}

	/**
	 * @author Matheus Gambarin
	 * @param usuario
	 * @return
	 * 
	 * 		Rota respons�vel por receber um json de usu�rio para inserir no
	 *         banco
	 */
	@POST
	@Path("/inserir")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces("application/json")
	public Response inserir(Usuario usuario) {
		return new UsuarioController().Inserir(usuario);
	}

	/**
	 * @author Matheus Gambarin
	 * @param id
	 * @return Rota respons�vel por retornar os dados do usu�rio
	 */
	@GET
	@Path("/dados/{id}")
	@Produces("application/json")
	public Response getUsuario(@PathParam("id") int id) {
		return new UsuarioController().GetUsuario(id);
	}

	/**
	 * @author Matheus Gambarin
	 * @param id
	 * @param usuario
	 *            Rota respons�vel por alterar o usu�rio
	 * @return
	 */
	@PUT
	@Path("/alterar/{id}")
	@Consumes("application/json")
	public Response alterarAnimal(@PathParam("id") int id, Usuario usuario) {
		return new UsuarioController().alterarUsuario(id, usuario);
	}

	/**
	 * @author Matheus Gambarin
	 * @param email
	 * @param senha
	 *            Rota respons�vel por realizar login
	 * @return
	 */
	@POST
	@Path("/login/{email}/{senha}")
	@Produces("application/json")
	public Response Login(@PathParam("email") String email, @PathParam("senha") String senha) {
		return new UsuarioController().login(email, senha);
	}
}
