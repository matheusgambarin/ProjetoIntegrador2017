package api.projetointegrador2017.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import api.projetointegrador2017.controller.EnderecoController;

/**
 * 
 * @author Matheus Gambarin
 * 
 *         Classe respons�vel por conter as rotas de Endere�o
 */
@Path("/endereco")
public class EnderecoResource {

	@GET
	@Produces("application/json")
	@Path("/{usuarioid}")
	public Response buscarEnderecoUsuario(@PathParam("usuarioid") int usuarioID) {
		return new EnderecoController().getEnderecoUsuario(usuarioID);
	}
}
