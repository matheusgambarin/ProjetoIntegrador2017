package projetointegrador.service;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import projetointegrador.entity.Endereco;
import projetointegrador.repository.EnderecoRepository;

@Service
public class EnderecoService {

	@Autowired
	private EnderecoRepository repo;

	public Endereco addEndereco(Endereco endereco) {
		endereco.setData_Cadastro(Date.valueOf(LocalDate.now()));
		endereco.setData_Alteracao(Date.valueOf(LocalDate.now()));
		endereco.setExcluido(false);
		endereco.setNovo(true);
		return repo.save(endereco);
	}
}
