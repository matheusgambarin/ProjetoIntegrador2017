package projetointegrador.service;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import projetointegrador.entity.Usuario;
import projetointegrador.repository.UsuarioRepository;

@Service
public class UsuarioService {

	@Autowired
	private UsuarioRepository repo;

	public Usuario getById(Long id) {
		return repo.findOne(id);
	}

	public Usuario addUser(Usuario user) {
		user.setData_Cadastro(Date.valueOf(LocalDate.now()));
		user.setData_Alteracao(Date.valueOf(LocalDate.now()));
		user.setExcluido(false);
		user.setNovo(true);
		return repo.save(user);
	}

	public Usuario updateUser(Usuario user) {
		user.setData_Alteracao(Date.valueOf(LocalDate.now()));
		return repo.save(user);
	}

	public Boolean login(Usuario user) {
		Usuario existe = repo.findByEmailAndSenha(user.getEmail(), user.getSenha());
		if (existe == null) {
			return Boolean.FALSE;
		}

		return Boolean.TRUE;
	}

}
