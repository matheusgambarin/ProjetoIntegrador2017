package projetointegrador.service;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import projetointegrador.entity.Animal;
import projetointegrador.repository.AnimalRepository;

@Service
public class AnimalService {

	private static final String UPLOADED_FOLDER = "../projeto/web/images/";
	@Autowired
	private AnimalRepository animalRepo;

	public List<Animal> getAll() {
		return animalRepo.findByAtivo(true);
	}

	public List<Animal> getAllVenda() {
		return animalRepo.findByAtivoAndTipo(true, 0);
	}

	public List<Animal> getAllAdocao() {
		return animalRepo.findByAtivoAndTipo(true, 1);
	}

	public List<Animal> filter(int tipo, String description) {
		return animalRepo.findByAtivoAndTipoAndComentarioOrNomeOrRacaOrSexo(true, tipo, description, description,
				description, description);
	}

	public List<Animal> filterAll(String description) {
		return animalRepo.findByAtivoAndComentarioOrNomeOrRacaOrSexo(true, description, description, description,
				description);
	}

	public List<Animal> getAllPerdido() {
		return animalRepo.findByAtivoAndTipo(true, 2);
	}

	public List<Animal> getAllByUsuarioId(Long usuarioId) {
		return animalRepo.findByAtivoAndUsuarioId(true, usuarioId);
	}

	public Animal addAnimal(Animal animal) {
		animal.setData_Cadastro(java.sql.Date.valueOf(LocalDate.now()));
		animal.setData_Alteracao(java.sql.Date.valueOf(LocalDate.now()));
		animal.setAtivo(true);
		animal.setExcluido(false);
		animal.setNovo(true);
		return animalRepo.save(animal);
	}

	public Animal updateAnimal(Animal animal) {
		animal.setData_Alteracao(java.sql.Date.valueOf(LocalDate.now()));
		return animalRepo.save(animal);
	}

	public void deletarAnimal(int id) {
		Animal animal = animalRepo.findOne(id);
		animal.setAtivo(false);
		animalRepo.save(animal);
	}

	public Animal findOne(int id) {
		return animalRepo.findOne(id);
	}

	public String upload(MultipartFile file, RedirectAttributes redirectAttributes) {
		if (file.isEmpty()) {
			redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
		}

		try {
			byte[] bytes = file.getBytes();
			java.nio.file.Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
			Files.write(path, bytes);
			System.out.println(path);
			redirectAttributes.addFlashAttribute("message",
					"You successfully uploaded '" + file.getOriginalFilename() + "'");
			return file.getOriginalFilename();

		} catch (java.io.IOException e) {
			e.printStackTrace();
			return e.toString();
		}
	}

}
