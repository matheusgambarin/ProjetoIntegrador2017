package projetointegrador.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import projetointegrador.entity.Animal;


@Repository
public interface AnimalRepository extends CrudRepository<Animal, Integer> {

	@Query("from Animal where  ativo = :#{#ativo} AND tipo = :#{#tipo} AND  (comentario like %:#{#comentario}%"
			+ " OR nome like %:#{#nome}% OR raca like %:#{#raca}% OR sexo like %:#{#sexo}%)")
	public List<Animal> findByAtivoAndTipoAndComentarioOrNomeOrRacaOrSexo(@Param("ativo") boolean ativo,
			@Param("tipo") int tipo, @Param("comentario") String comentario, @Param("nome") String nome,
			@Param("raca") String raca, @Param("sexo") String sexo);

	public List<Animal> findByAtivoAndComentarioOrNomeOrRacaOrSexo(boolean ativo, String comentario, String nome,
			String raca, String sexo);

	public List<Animal> findByAtivo(boolean ativo);

	public List<Animal> findByAtivoAndTipo(boolean ativo, int tipo);

	public List<Animal> findByAtivoAndUsuarioId(boolean ativo, Long usuarioid);
}
