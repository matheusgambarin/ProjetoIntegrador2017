package projetointegrador.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "Usuario")
public class Usuario {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	@NotNull
	@Column(name = "email", unique = true)
	private String email;
	@NotNull
	@Column(name = "senha", nullable = false)
	private String senha;
	@ManyToOne(optional = true)
	@JoinColumn(name = "enderecoid", insertable = false, updatable = false)
	private Endereco endereco;
	private int enderecoid;
	@NotNull
	@Column(name = "telefone")
	private String telefone;	
	@NotNull
	@Column(name = "nome", nullable = false)
	private String nome;
	@NotNull
	@Column(name = "Data_Cadastro", nullable = false)
	private Date Data_Cadastro;
	@NotNull
	@Column(name = "Data_Alteracao", nullable = false)
	private Date Data_Alteracao;
	@NotNull
	@Column(name = "excluido", nullable = false)
	private boolean excluido;
	@NotNull
	@Column(name = "novo", nullable = false)
	private boolean novo;

	public Date getData_Cadastro() {
		return Data_Cadastro;
	}

	public void setData_Cadastro(Date data_Cadastro) {
		Data_Cadastro = data_Cadastro;
	}

	public Date getData_Alteracao() {
		return Data_Alteracao;
	}

	public void setData_Alteracao(Date data_Alteracao) {
		Data_Alteracao = data_Alteracao;
	}

	public boolean isExcluido() {
		return excluido;
	}

	public void setExcluido(boolean excluido) {
		this.excluido = excluido;
	}

	public boolean isNovo() {
		return novo;
	}

	public void setNovo(boolean novo) {
		this.novo = novo;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getEnderecoid() {
		return enderecoid;
	}

	public void setEnderecoid(int enderecoid) {
		this.enderecoid = enderecoid;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	
	
}