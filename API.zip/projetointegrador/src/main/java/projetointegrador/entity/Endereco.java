package projetointegrador.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "Endereco")
public class Endereco {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	@NotNull
	@Column(name = "numero", nullable = false)
	private String numero;
	@NotNull
	@Column(name = "rua", nullable = false)
	private String rua;
	@NotNull
	@Column(name = "cidade", nullable = false)
	private String cidade;
	@NotNull
	@Column(name = "uf", nullable = false)
	private String uf;
	@NotNull
	@Column(name = "complemento", nullable = false)
	private String complemento;
	@NotNull
	@Column(name = "bairro", nullable = false)
	private String bairro;
	@NotNull
	@Column(name = "Data_Cadastro", nullable = false)
	private Date Data_Cadastro;
	@NotNull
	@Column(name = "Data_Alteracao", nullable = false)
	private Date Data_Alteracao;
	@NotNull
	@Column(name = "excluido", nullable = false)
	private boolean excluido;
	@NotNull
	@Column(name = "novo", nullable = false)
	private boolean novo;

	public Date getData_Cadastro() {
		return Data_Cadastro;
	}

	public void setData_Cadastro(Date data_Cadastro) {
		Data_Cadastro = data_Cadastro;
	}

	public Date getData_Alteracao() {
		return Data_Alteracao;
	}

	public void setData_Alteracao(Date data_Alteracao) {
		Data_Alteracao = data_Alteracao;
	}

	public boolean isExcluido() {
		return excluido;
	}

	public void setExcluido(boolean excluido) {
		this.excluido = excluido;
	}

	public boolean isNovo() {
		return novo;
	}

	public void setNovo(boolean novo) {
		this.novo = novo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

}
