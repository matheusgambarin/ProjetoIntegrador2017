package projetointegrador.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "animal")
public class Animal {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	@Column(name = "nome", nullable = false)
	private String nome;
	@Column(name = "raca")
	private String raca;
	@Column(name = "comentario")
	private String comentario;
	@Column(name = "sexo", nullable = false)
	private String sexo;
	@ManyToOne(optional = false)
	@JoinColumn(name = "usuarioid", insertable = false, updatable = false)
	private Usuario usuario;
	@Column(nullable = false)
	private Long usuarioid;
	@Column(name = "perdido")
	private boolean perdido;
	@Column(name = "url")
	private String url;
	@Column(name = "ativo", nullable = false)
	private boolean ativo;
	@Column(name = "tipo", nullable = false)
	private int tipo;
	@Column(name = "Data_Cadastro", nullable = false)
	private Date Data_Cadastro;
	@Column(name = "Data_Alteracao", nullable = false)
	private Date Data_Alteracao;
	@Column(name = "excluido", nullable = false)
	private boolean excluido;
	@Column(name = "novo", nullable = false)
	private boolean novo;

	public Usuario getUsuario() {
		return usuario;
	}

	public Date getData_Cadastro() {
		return Data_Cadastro;
	}

	public void setData_Cadastro(Date data_Cadastro) {
		Data_Cadastro = data_Cadastro;
	}

	public Date getData_Alteracao() {
		return Data_Alteracao;
	}

	public void setData_Alteracao(Date data_Alteracao) {
		Data_Alteracao = data_Alteracao;
	}

	public boolean isExcluido() {
		return excluido;
	}

	public void setExcluido(boolean excluido) {
		this.excluido = excluido;
	}

	public boolean isNovo() {
		return novo;
	}

	public void setNovo(boolean novo) {
		this.novo = novo;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getId() {
		return id;
	}

	public Long getUsuarioid() {
		return usuarioid;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRaca() {
		return raca;
	}

	public void setRaca(String raca) {
		this.raca = raca;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public boolean isPerdido() {
		return perdido;
	}

	public void setPerdido(boolean perdido) {
		this.perdido = perdido;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public boolean isAtivo() {
		return ativo;
	}

	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public void setUsuarioid(Long usuarioid) {
		this.usuarioid = usuarioid;
	}

}
