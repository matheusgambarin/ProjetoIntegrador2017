package projetointegrador.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import projetointegrador.entity.Animal;
import projetointegrador.service.AnimalService;

@Controller
@RequestMapping("/animal")
public class AnimalController {

	@Autowired
	private AnimalService animalService;

	@GetMapping
	public ResponseEntity<List<Animal>> getAll(
			@RequestParam(name = "filter", required = false) Optional<String> filter) {
		if (filter.get().isEmpty())
			return ResponseEntity.ok().body(animalService.getAll());
		return ResponseEntity.ok().body(animalService.filterAll(filter.get()));
	}

	@GetMapping("/{id}")
	public ResponseEntity<Animal> findOne(@PathVariable int id) {
		return ResponseEntity.ok().body(animalService.findOne(id));
	}

	@GetMapping("/venda")
	public ResponseEntity<List<Animal>> getAllVenda(
			@RequestParam(name = "filter", required = false) Optional<String> filter) {
		if (filter.get().isEmpty())
			return ResponseEntity.ok().body(animalService.getAllVenda());
		return ResponseEntity.ok().body(animalService.filter(0, filter.get()));
	}

	@GetMapping("/adocao")
	public ResponseEntity<List<Animal>> getAllAdocao(
			@RequestParam(name = "filter", required = false) Optional<String> filter) {
		if (filter.get().isEmpty())
			return ResponseEntity.ok().body(animalService.getAllAdocao());
		return ResponseEntity.ok().body(animalService.filter(1, filter.get()));
	}

	@GetMapping("/perdido")
	public ResponseEntity<List<Animal>> getAllPerdido(
			@RequestParam(name = "filter", required = false) Optional<String> filter) {
		if (filter.get().isEmpty())
			return ResponseEntity.ok().body(animalService.getAllPerdido());
		return ResponseEntity.ok().body(animalService.filter(2, filter.get()));
	}

	@GetMapping("/meusanuncios/{usuarioid}")
	public ResponseEntity<List<Animal>> getAllByUsuarioID(@PathVariable Long usuarioid) {
		return ResponseEntity.ok().body(animalService.getAllByUsuarioId(usuarioid));
	}

	@PostMapping("/imagem")
	public ResponseEntity<String> addImage(@RequestParam("file") MultipartFile file,
			RedirectAttributes redirectAttributes) {
		String result = animalService.upload(file, redirectAttributes);
		return ResponseEntity.ok().body(result);
	}

	@PostMapping
	public ResponseEntity<Animal> addAnimal(@RequestBody Animal animal) {
		return ResponseEntity.ok().body(animalService.addAnimal(animal));
	}

	@PutMapping
	public ResponseEntity<Animal> updateAnimal(@RequestBody Animal animal) {
		return ResponseEntity.ok().body(animalService.updateAnimal(animal));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deletarAnimal(@PathVariable("id") int id) {
		animalService.deletarAnimal(id);
		return ResponseEntity.ok("Excluido com sucesso");
	}
}
