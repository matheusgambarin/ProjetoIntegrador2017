package projetointegrador.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import projetointegrador.entity.Endereco;
import projetointegrador.service.EnderecoService;

@RestController
@RequestMapping("/endereco")
@CrossOrigin
public class EnderecoController {

	@Autowired
	private EnderecoService enderecoService;

	@PostMapping
	public ResponseEntity<Endereco> addEndereco(@RequestBody Endereco endereco) {
		return ResponseEntity.ok().body(enderecoService.addEndereco(endereco));
	}
}
